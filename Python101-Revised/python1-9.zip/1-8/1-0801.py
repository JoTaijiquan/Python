#Example 8.01
#Python3.6.5

def example_801():
    x={ 'a': 'Hello',
        'b': 'World',
        'c': '!!!'
        }

    print (x)

example_801()

'''
ข้อมูลใน {} เรียกว่า dictionary
ประกอบด้วย key และ value ในรูป
{key: value}

แสดงผล
{'a': 'Hello', 'b': 'World', 'c': '!!!'}
'''

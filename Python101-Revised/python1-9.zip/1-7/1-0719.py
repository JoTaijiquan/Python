#Example 7.19
#Python3.6.5

def example_719(x,y,z):
    return [x,y,z]

print (example_719(10,20,[1,3,5]))

'''
return เป็น list ซ้อน list กันเลย

แสดงผล
[10, 20, [1, 3, 5]]
'''

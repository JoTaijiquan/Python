#Example 7.17
#Python3.6.5

def example_717(x,y,z):
    return [x,y,z]

x = example_717(10,20,30)
print (x)

'''
return ออกมาเป็น list ก็ได้ ซึ่งทำให้ได้ค่าออกมาเป็นชุดหลายๆ ตัวได้

แสดงผล
[10, 20, 30]
'''

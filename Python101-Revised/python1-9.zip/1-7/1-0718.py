#Example 7.18
#Python3.6.5

def example_718(x,y,z):
    return(x,y,z)

x = example_718(1,2,3)
print (x)

'''
นอกจาก return เป็น list ยัง return เป็น tuple ก็ได้

แสดงผล
(1, 2, 3)
'''

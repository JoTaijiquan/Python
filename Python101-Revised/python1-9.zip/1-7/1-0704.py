#Example 7.04
#Python3.6.5

def example_704(x,y):
    print ("x=",x)
    print ("y=",y)
    print ()

x=10; y=20; a=30; b=40;
example_704(x,y)
example_704(a,b)


'''
ส่งค่าตัวแปร2 ตัว เข้าไปใน function 

แสดงผล
x= 10
y= 20
x= 30
y= 40
'''

#Example 7.01
#Python3.6.5

def example_701():
    print ("Hello")

example_701()

'''
แสดงผล
Hello
'''

#Example 7.24
#Python3.6.5

def example_724():
    #Document
    pass

print(example_724.__doc__)

'''
document ของ function ต้องอยู่ในเครื่องหมาย ''' '''
เท่านั้น ใช้ # จะไม่ได้ ดังตัวอย่างเมื่อสั่ง
print(example_724.__doc__) จะได้ผลเป็น None

แสดงผล
None
'''

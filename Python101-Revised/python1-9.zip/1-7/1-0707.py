#Example 7.07
#Python3.6.5

def example_707(x,y):
    print ("x=",x)
    print ("y=",y)

x = [10,20,30]
y = 1,1,2,3,5,8

example_707(x,y)


'''
ส่งตัวแปรทั้ง list และ tuple เข้าไปใน function 

แสดงผล
x= [10, 20, 30]
y= (1, 1, 2, 3, 5, 8)
'''

#Example 7.02
#Python3.6.5

def example_702(x):
    print ("x=",x)

example_702(10)
example_702("Hello")
example_702(3+4)
example_702((3,4,5))


'''
ส่งค่าตัวแปรเข้าไปใน function 

แสดงผล
x= 10
x= Hello
x= 7
x= (3, 4, 5)
'''

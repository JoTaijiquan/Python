#Example 7.23
#Python3.6.5

def example_723():
    '''Document
    !!! '''
    pass

example_723()
print (example_723.__doc__)

'''
ในการทำงานกันหลายๆ คน หรือในกรณีที่เขียนชื่อ function ลอยๆ ไว้ก่อน
กันลืม เราสามารถสร้างเอกสารประกอบไว้ใน function ก่อนได้ตามตัวอย่าง
คำสั่ง print (example_723.__doc__) จะแสดงผลคอมเมนต์ที่วางไว้ใน
บรรทัดต่อจากชื่อ function ออกมา

แสดงผล
Document
    !!! 
'''

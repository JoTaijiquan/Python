#Example 7.09
#Python3.6.5

def example_709(x,y=10):
    print (x,y)

example_709(10,20)
example_709(10)
example_709("Hello")


'''
กำหนดค่าให้กับตัวแปรที่จะส่งค่าเข้าไปใน function ก่อนได้

แสดงผล
10 20
10 10
Hello 10
'''

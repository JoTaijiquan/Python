#Example 7.11
#Python3.6.5

def example_711(a=1,b=2,c=3):
    print (a,b,c)

example_711()
example_711(10,c=20)

'''
กำหนดค่าให้กับตัวแปรที่จะส่งค่าเข้าไปใน function ทั้งสามตัว

แสดงผล
1 2 3
10 2 20
'''

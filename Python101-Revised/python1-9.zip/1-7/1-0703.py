#Example 7.03
#Python3.6.5

def example_703(x,y):
    print ("x=",x)
    print ("y=",y)
    print()

example_703(10,20)
example_703("Hello",10)


'''
ส่งค่าตัวแปร2 ตัว เข้าไปใน function 

แสดงผล
x= 10
y= 20

x= Hello
y= 10
'''

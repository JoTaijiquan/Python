#Example 5.01
#Python3.6.5

def example_501():    
    a = [1,2,3,4,5]
    b = ["abc",2,3,False]

    print ("1) a=",a)
    print ("2) b=",b)
    print ("3) type of a = ",type(a))
    print ("4) type of b = ",type(b))

example_501()

'''
a = [1,2,3,4,5]         เป็นการสร้างตัวแปรชนิดลิสต์
b = ["abc",2,3,False]   ลิสต์สามารถมีค่าเป็น string integer boolean หรือลิสต์เองก็ได้

แสดงผล
1) a= [1, 2, 3, 4, 5]
2) b= ['abc', 2, 3, False]
3) type of a =  <class 'list'>
4) type of b =  <class 'list'>
'''

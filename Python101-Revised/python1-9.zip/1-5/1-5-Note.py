#Python3.6.5
#Note

#Example 5.01 list

#Example 5.02 list index

#Example 5.03 list minus index

#Example 5.04 list in list

#Example 5.05 type of variable and list

#Example 5.06 list append

#Example 5.07 list count

#Example 5.08 list remove

#Example 5.09  append remove



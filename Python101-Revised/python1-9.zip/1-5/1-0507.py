#Example 5.07
#Python3.6.5

def example_507():
    a = [1,2,3,4,5,6,3,4,3,6]

    print ("1) a=",a)
    print ("2) count 3? =",a.count(3))
    print ("3) count 6? =",a.count(6))

example_507()

'''
print ("1) a=",a) แสดงค่าใน a = [1, 2, 3, 4, 5, 6, 3, 4, 3, 6]
print ("2) count 3? =",a.count(3)) นับจำนวน 3 ได้ 3 ตัว
print ("3) count 6? =",a.count(6)) นับจำนวน 6 ได้ 2 ตัว

แสดงผล
1) a= [1, 2, 3, 4, 5, 6, 3, 4, 3, 6]
2) count 3? = 3
3) count 6? = 2
'''

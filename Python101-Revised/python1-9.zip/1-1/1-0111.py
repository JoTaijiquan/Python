#Example 1.11
#Python3.6.5

print (r"Hello World /n")
print (r"Hello /t World // /n")

'''
raw string จะพิมพ์ทุกตัวในเครื่องหมาย " ออกมาโดยไม่สนใจ escape charactor

print (r"Hello World /n")           แสดงผล Hello World /n
print (r"Hello /t World // /n")     แสดงผล Hello /t World // /n
'''

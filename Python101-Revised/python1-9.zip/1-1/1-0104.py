#Example 1.04
#Python3.6.5

print ("3x4 =",3*4)   
print ("Hello"+"!")
print ("Hello!"*3)

'''
print ("3x4 =")     แสดงผล 3x4 = 12   
print ("Hello"+"!") แสดงผล Hello!
print ("Hello!"*3)  แสดงผล Hello!Hello!Hello!
'''

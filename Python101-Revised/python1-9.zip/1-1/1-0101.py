#Example 1.01
#Python 3.6.5

print ("Hello World!")

'''
#Ecample 1.01 บันทึกเฉยๆ ไม่มีผลอะไร
#Python 3.6.5 บันทึกเฉยๆ ไม่มีผลอะไร
print ("Hello World!")    แสดงผล Hello World!
'''

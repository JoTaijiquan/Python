#Example 1.14
#Python3.6.5

#Example 1.01 print Hello World

#Example 1.02 print coding: utf-8

#Example 1.03 print math

#Example 1.04 print concatenate

#Example 1.05 print separator

#Example 1.06 print ending

#Example 1.07 print escape

#Example 1.08 print escape character

#Example 1.09 print multiline

#Example 1.10 print format

#Example 1.11 print raw

#Example 1.12 define function with def

#Example 1.13 self document

##xample 1.14 print name & doc

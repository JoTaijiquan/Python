#Example 1.08
#Python3.6.5

print ("Hello\n")       #escape character \n สั่งขึ้นบรรทัดใหม่     
print ("World!")
print ("Hello\n\n")     # \n\n ขึ้นบรรทัดใหม่สองครั้ง
print ("World!")
print ("Hello\tWorld!") #\t เว้นวรรค tab

'''
escape character เพิ่มเติม
แสดงผล

Hello

World!
Hello


World!
Hello	World!
'''

#Example 1.10
#Python3.6.5

print ("Hello {0}")
print ("Hello {0} World! {1}".format(3,10))
print ("Hello {1} World! {0}".format(3,10))

'''
print ("Hello {0}")                         แสดงผล Hello {0}
print ("Hello {0} World! {1}".format(3,10)) แสดงผล Hello 3 World! 10
print ("Hello {1} World! {0}".format(3,10)) แสดงผล Hello 10 World! 3
'''

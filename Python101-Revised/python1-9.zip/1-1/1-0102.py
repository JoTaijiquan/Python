# -*- coding: utf-8 -*-
#Example 1.02
#Python3.6.5


print ("Hello World!")
print ("สวัสดี ชาวโลก")

'''
# -*- coding: utf-8 -*-   ให้แสดงผลด้วยรหัส utf-8 สำหรับแสดงภาษาไทย
print ("Hello World!")    แสดงผล Hello World! 
print ("สวัสดี ชาวโลก")     แสดงผล สวัสดีชาวโลก   
'''

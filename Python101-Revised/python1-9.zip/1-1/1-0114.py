#Example 1.14
#Python3.6.5

def example_114():
    '''Example 1.14 Document,
    Write any thing here!!
    in multi-line'''
    
    print ("Hello")

print (example_114.__name__)
print (example_114.__doc__)


'''
เขียนคำอธิบายฟังก์ชันหลายบรรทัดได้


print (example_114.__name__)    แสดงผล example_114
print (example_114.__doc__)     แสดงผล Example 1.14 Document,
                                            Write any thing here!!
                                            in multi-line
 
'''

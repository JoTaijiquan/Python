#Example 1.12
#Python3.6.5

def example_112():
    print ("Hello!")

example_112()
example_112()
print ("World!")
example_112()
example_112()



'''
สร้างคำสั่งหรือ function ด้วย def
function ที่สร้างไว้แล้ว สามารถเรียกใช้ได้เรื่อยๆ 

example_112()       แสดงผล Hello!
example_112()       แสดงผล Hello!
print ("World!")    แสดงผล World!
example_112()       แสดงผล Hello!
example_112()       แสดงผล Hello!
'''

#Example 1.07
#Python3.6.5

print ("\"Hello\"")     #แสดงผล "Hello"
print ("\\Hello\\")     #แสดงผล \Hello\


'''
กรณีต้องการแสดงผล " ใช้ \"
กรณีต้องการแสดงผล \ ใช้ \\
เรียกว่า escape character
'''

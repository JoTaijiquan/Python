#Example 3.07
#Python3.6.5

import random
def example_307():
    
    x = random.randint(1,10)
    print (x)

example_307()

'''
import random เรียกโมดูลเกี่ยวกับ random มาใช้
x = random.randint(1,10)  กำหนดค่า x เป็นตัวเลขแรนดอมตั้งแต่ 1 ถึง 10

ลอง Run หลายๆ ครั้ง จะได้ค่าที่แสดงผลออกมาแตกต่างกันไป
'''

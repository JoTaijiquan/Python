#Example 3.02
#Python3.6.5

def example_302():
    x = 10
    y = 11
    
    if x is 10:
        print ("Yes, x =",x)
    if y is 10:
        print ("Yes, y =",y)

example_302()

'''
แสดงผล
Yes, x = 10
'''

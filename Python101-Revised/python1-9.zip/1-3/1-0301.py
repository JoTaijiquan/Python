#Example 3.01
#Python3.6.5

def example_301():
    x = 10
    y = 11
    
    if x==10:
        print ("Yes, x =",x)

    if y==10:
        print ("Yes, y =",10)
    
example_301()

'''
แสดงผล
Yes, x = 10
'''

#Python3.6.5
#Note

#Example 3.01 if

#Example 3.02 if

#Example 3.03 if else

#Example 3.04 if elif else

#Example 3.05 input

#Example 3.06 input if

#Example 3.07 random

#Example 3.08 guess number

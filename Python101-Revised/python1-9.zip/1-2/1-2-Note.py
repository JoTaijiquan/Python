#Python3.6.5
#Note

#Example 2.01 variable set

#Example 2.02 variable swap

#Example 2.03 multiple variable set

#Example 2.04 variable type

#Example 2.05 string

#Example 2.06 number

#Example 2.07 show variable type

#Example 2.08 math operator

#Example 2.09 logic operator

#Example 2.10 number type

#Example 2.11 change number type 

#Example 1.12 multiple command in one line

#Example 1.13 multiple line command

##xample 1.14 print name & doc

#Example 2.10
#Python3.6.5

def example_210():
    print ("1) 3x10 power 5 =",3e5)
    print ("2) type of 3e5 =",type(3e5))
    print ("3) 3x10 power 5 =",3*10**5)
    print ("4) type of 3*10**5 =",type(3*10**5))
    print ("5) 3.12345 * 10 power 5 =",3.12345e5)
    print ("6) type of 3.12345e5 =",type(3.12345e5))
    print ("7) 3.12345 * 10 power 5 =",3.12345*10**5)
    print ("8) type of 3.12345 * 10**5 =",type(3.12345*10**5))

example_210()

'''
ศึกษาชนิดของตัวแปร

แสดงผล
1) 3x10 power 5 = 300000.0
2) type of 3e5 = <class 'float'>
3) 3x10 power 5 = 300000
4) type of 3*10**5 = <class 'int'>
5) 3.12345 * 10 power 5 = 312345.0
6) type of 3.12345e5 = <class 'float'>
7) 3.12345 * 10 power 5 = 312345.0
8) type of 3.12345 * 10**5 = <class 'float'>
'''

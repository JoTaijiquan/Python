#Example 2.03
#Python3.6.5

def example_203():
    a = b = 2
    c = d = 4
    print ("1) a,b,c,d =",a,b,c,d)

example_203()

'''
a = b = 2                       กำหนดค่า a และ b = 2
c = d = 4                       กำหนดค่า c และ d = 4
print ("1) a,b,c,d =",a,b,c,d)  แสดงผล 1) a,b,c,d = 2 2 4 4
'''

#Example 2.11
#Python3.6.5

def example_211():
    print ("1) interger of 3.5 =",int(3.5))
    print ("2) float of 3 =",float(3))
    print ("3) 3+3 =",3+3)
    print ("4) float of 3+3 =",float(3+3))
    print ("5) string of 3 + string of 3 =",str(3)+str(3))
    print ("6) \"3\" , \"3\" =","3","3")
    print ("7) \"3\" + \"3\" =","3"+"3")

example_211()

'''
แปลงชนิดตัวแปร
int()    แปลงตัวเลขเป็นชนิด integer
float()  แปลงตัวเลขเป็น floating point
string() แปลงตัวเลขเป็น string เก็บตัวอักษร

แสดงผล
1) interger of 3.5 = 3
2) float of 3 = 3.0
3) 3+3 = 6
4) float of 3+3 = 6.0
5) string of 3 + string of 3 = 33
6) "3" , "3" = 3 3
7) "3" + "3" = 33
'''

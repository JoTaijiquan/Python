#Example 2.01
#Python3.6.5

def example_201():
    a = 2
    b = 999988887777 
    c = 3.14159
    d = "ABC"
    e = True
    f = False

    print ("1) a=",a)
    print ("2) b=",b)
    print ("2) c=",c)
    print ("4) d=",d,"e=",e, "f=",f)

    a = b = c
    print ("5)",a,b,c)

example_201()

'''
a = 2               กำหนดค่าตัวแปร a = 2
b = 999988887777    กำหนดค่าตัวแปร b = 999988887777 
c = 3.14159         กำหนดค่าตัวแปร c = 3.14159
d = "ABC"           กำหนดค่าตัวแปร d = "ABC"
e = True            กำหนดค่าตัวแปร e = True (จริง)
f = False           กำหนดค่าตีัวแปร f = False (เท็ํจ)
'''

#Example 2.08
#Python3.6.5

def example_208():
    a,b = 9,8
    print ("1) a+b =",a+b)
    print ("2) a-b =",a-b)
    print ("3) axb =",a*b)
    print ("4) a/b =",a/b)
    print ("5) a//b =",a//b) #หารเอาส่วน
    print ("6) a mod b =",a%b) #หารเอาเศษ
    print ("7) a power b =",a**b) #ยกกำลัง
    print ("8) 3*4+2*3**2*(1+1) =",3*4+2*3**2*(1+1))

example_208()

'''
print ("1) a+b =",a+b)                              แสดงผล 1) a+b = 17
print ("2) a-b =",a-b)                              แสดงผล 2) a-b = 1
print ("3) axb =",a*b)                              แสดงผล 3) axb = 72
print ("4) a/b =",a/b)                              แสดงผล 4) a/b = 1.125
print ("5) a//b =",a//b) #หารเอาส่วน                 แสดงผล 5) a//b = 1
print ("6) a mod b =",a%b) #หารเอาเศษ               แสดงผล 6) a mod b = 1
print ("7) a power b =",a**b) #ยกกำลัง               แสดงผล 7) a power b = 43046721
print ("8) 3*4+2*3**2*(1+1) =",3*4+2*3**2*(1+1))    แสดงผล 8) 3*4+2*3**2*(1+1) = 48
'''

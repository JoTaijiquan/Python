#Example 6.02
#Python3.6.5

def example_602():
    for i in ("abc",True,2,(3,4,5),"def"): print (i)

example_602()

'''
แสดงผล
abc
True
2
(3, 4, 5)
def
'''

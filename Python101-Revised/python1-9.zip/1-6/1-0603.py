#Example 6.03
#Python3.6.5

def example_603():
    for i in [2,4,6,8,10]:
        print(i)

example_603()

'''
แสดงผล
2
4
6
8
10
'''

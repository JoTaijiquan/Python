#Example 6.09
#Python3.6.5

def example_609():
    for i in ("Superman", "Batman", "Aquaman"):
        print ("Hello",i)

example_609()

'''
แสดงผล
Hello Superman
Hello Batman
Hello Aquaman
'''

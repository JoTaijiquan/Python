#Example 6.08
#Python3.6.5

def example_608():
    for i in str(3.14159):
        print (i)

example_608()

'''
แปลงตัวเลขเป็น string ด้วย str()
ใช้จำนวนตัวอักษรใน string กำหนดจำนวนลูป (วงรอบ)

แสดงผล
3
.
1
4
1
5
9
'''

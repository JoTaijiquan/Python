#Example 6.01
#Python3.6.5

def example_601():
    for i in (1,1,2,3,5,8,13):
        print (i)

example_601()

'''
แสดงผล
1
1
2
3
5
8
13
'''

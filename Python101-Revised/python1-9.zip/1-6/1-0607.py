#Example 6.07
#Python3.6.5

def example_607():
    for i in "Hello World!":
        print (i)

example_607()

'''
ใช้จำนวนตัวอักษรใน string เป็นตัวกำหนดวงรอบก็ได้

แสดงผล
H
e
l
l
o
 
W
o
r
l
d
!
'''

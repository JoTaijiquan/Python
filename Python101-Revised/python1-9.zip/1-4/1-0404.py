#Example 4.04
#Python3.6.5

def example_404():
    for i in range(10,1,-1):
        print (i)

example_404()

'''
for i in range(10,1,-1): สั่งวนรอบตั้งแต่ 10 >1 ลดทีละ -1
    print (i)            แสดงค่าของ i แต่ละรอบ
    
แสดงผล
10
9
8
7
6
5
4
3
2
'''

#Python3.6.5
#Note

#Example 4.01 for in range 10

#Example 4.02 for in range 1 to 10

#Example 4.03 for in range 1 to 11 step 2

#Example 4.04 for in range from 10 to 1 step -1

#Example 4.05 for in range -10 to 10 step 2

#Example 4.06 for in range 10 to -10 step -2

#Example 4.07 for in range and change value of counter in middle of loop

#Example 4.08 for in range and operate with counter

#Example 4.09  while counter +=1

#Example 4.10 while counter +=2

#Example 4.11 while counter -=2

#Example 4.12 while counter *=2

#Example 4.13 while counter **=2

#Example 4.14 while true

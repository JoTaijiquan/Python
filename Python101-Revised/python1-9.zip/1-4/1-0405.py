#Example 4.05
#Python3.6.5

def example_405():
    for i in range(-10,10,2):
        print (i)

example_405()

'''
for i in range(-10,10,2): สั่งวนรอบตั้งแต่ -10 <10 นับเพิ่มทีละ 2
    print (i)             แสดงค่าของ i แต่ละรอบ
    
แสดงผล
-10
-8
-6
-4
-2
0
2
4
6
8
'''

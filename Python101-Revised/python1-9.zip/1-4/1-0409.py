#Example 4.09
#Python3.6.5

def example_409():
    x=1
    while x<5:
        print ("x =",x)
        x=x+1

example_409()

'''
while x<5 ให้วนรอบ ตราบที่เงื่อนไขยังเป็นจริง ในกรณีนี้คือวนรอบตราบที่ x<5
    print ("x =",x) แสดงค่า x
    x=x+1 บวกค่า x  ทีละ 1
    
แสดงผล
x = 1
x = 2
x = 3
x = 4
'''

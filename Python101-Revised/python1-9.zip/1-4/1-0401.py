#Example 4.01
#Python3.6.5

def example_401():
    for i in range(10):
        print (i)

example_401()

'''
for i in range(10): สั่งวนรอบใน range(10) นับตั้งแต่ 0 นับเพิ่มตราบที่ยังน้อยกว่า 10 นำค่าในแต่ละรอบมาใส่ในตัวแปร i
    print (i)       แสดงค่าของ i แต่ละรอบ
    
แสดงผล
0
1
2
3
4
5
6
7
8
9
'''

#Example 4.02
#Python3.6.5

def example_402():
    for i in range(1,10):
        print (i)

example_402()

'''
for i in range(1,10): สั่งวนรอบใน range(1,10) นับตั้งแต่ 1 นับเพิ่มตราบที่ยังน้อยกว่า 10
    print (i)         แสดงค่าของ i แต่ละรอบ
    
แสดงผล
1
2
3
4
5
6
7
8
9
'''

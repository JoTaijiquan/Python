#Example 4.08
#Python3.6.5

def example_408():
    for i in range(10):
        print (i+1)

example_408()

'''
เนื่องจาก i = 0-9 แล้วสั่งแสดงผลเป็น i+1 จึงได้เป็น 1 2 3 4 5 6 7 8 9 10
    
แสดงผล
1
2
3
4
5
6
7
8
9
10
'''

#Example 4.03
#Python3.6.5

def example_403():
    for i in range(1,11,2):
        print (i)

example_403()

'''
for i in range(1,111,2): สั่งวนรอบตั้งแต่ 1 <11 เพิ่มทีละ 2 
    print (i)       แสดงค่าของ i แต่ละรอบ
    
แสดงผล
1
3
5
7
9
'''
